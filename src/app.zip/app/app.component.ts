import { Component } from '@angular/core';





@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pfa';
myimage: string = "assets/images/https://www.google.com/search?q=municipalit%C3%A9-denden.png&rlz=1C1GCEU_frTN960TN960&sxsrf=ALeKk01G9jcCyPevi5VzHpr40p9MdZFBTA:1628113396864&tbm=isch&source=iu&ictx=1&fir=iMbP4S3rOIRTSM%252C5gx7ArwEYLpAsM%252C_&vet=1&usg=AI4_-kQ2Gju0t0CicKmYkncUVrq_cfFi9A&sa=X&ved=2ahUKEwjxzbGFq5jyAhXjoFwKHdeaBo0Q9QF6BAgQEAE&biw=1536&bih=754#imgrc=iMbP4S3rOIRTSM" 
}

