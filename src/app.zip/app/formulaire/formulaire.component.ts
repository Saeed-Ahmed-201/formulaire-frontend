import {  Component, OnInit } from '@angular/core';
import {  FormGroup , FormControl, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-formulaire',
  templateUrl: './formulaire.component.html',
  styleUrls: ['./formulaire.component.css'],
})
export class FormulaireComponent implements OnInit{ 
  public formulaireForm : FormGroup | any;
  counter(i:number){
    return new Array(i);
  } 
  ngOnInit(): void {
    this.formulaireForm = new FormGroup({
      date:new FormControl (''),
      nom: new FormControl(),
      prenom: new FormControl(),
      datenais: new FormControl(),
      adresse: new FormControl(),
      telephone1: new FormControl('',Validators.required),
      telephone2:new FormControl(),
      a:new FormControl(),
      b:new FormControl(),
      c:new FormControl(),
      total:new FormControl(),
      C:new FormControl(),
      D: new FormControl(),
      Dépensescontinentales4: new FormControl(),
      Dépensescontinentales5: new FormControl(),
      Dépensescontinentales2: new FormControl(),
      Dépensescontinentales3: new FormControl(),
      Dépensescontinentales1: new FormControl(),
     
    })
    
  }}